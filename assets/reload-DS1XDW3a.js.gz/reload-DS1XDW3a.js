import{d as o,x as t,j as n,y as r,o as a}from"./index-BjNVnGL4.js";const p=o({__name:"reload",setup(s){const e=r();return t(()=>{e.go(-1)}),(c,u)=>(a(),n("div"))}});export{p as default};
