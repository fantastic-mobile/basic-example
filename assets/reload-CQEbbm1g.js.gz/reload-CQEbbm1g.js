import{d as o,h as t,j as n,k as r,o as a}from"./index-tPS3C4DU.js";const p=o({__name:"reload",setup(s){const e=n();return t(()=>{e.go(-1)}),(c,u)=>(a(),r("div"))}});export{p as default};
